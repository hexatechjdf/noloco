<?php

return [
    'noloco' => 'Noloco',
];
