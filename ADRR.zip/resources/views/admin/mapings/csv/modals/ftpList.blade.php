<div class="modal fade" id="ftpModal" tabindex="-1" aria-labelledby="ftpModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="ftpModalLabel">Manage FTP Accounts</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body append-data">

                <!-- Tabs -->
                {{-- <ul class="nav nav-tabs" id="ftpTabs" role="tablist">
                    <li class="nav-item" role="presentation">
                        <button class="nav-link active" id="accounts-tab" data-bs-toggle="tab" data-bs-target="#accounts" type="button" role="tab">
                            Accounts List
                        </button>
                    </li>
                    <li class="nav-item" role="presentation">
                        <button class="nav-link" id="settings-tab" data-bs-toggle="tab" data-bs-target="#settings" type="button" role="tab">
                            Settings
                        </button>
                    </li>
                    <li class="nav-item" role="presentation">
                        <button class="nav-link" id="create-tab" data-bs-toggle="tab" data-bs-target="#create" type="button" role="tab">
                            Create Account
                        </button>
                    </li>
                </ul> --}}
{{--
                <div class="tab-content append-data mt-3">

                </div> --}}
            </div>
        </div>
    </div>
</div>
