
<div>
    <a class="btn btn-secondary btn-sm m-1 " href="{{route('admin.mappings.csv.outbound.create',$item->id)}}"><i class="bi bi-pencil-square"></i>Edit</a>
</div>
