<div class="row ">
    <div class="col-md-12">
        <div class="alert alert-primary d-flex justify-content-between justify-between" role="alert">
            <h4 class="h4 text-uppercase">{{ $title }}</h4>
            @if (@$button)
                <button class="btn btn-warning generate_url">Generate Url</button>
            @endif
        </div>


    </div>
</div>
