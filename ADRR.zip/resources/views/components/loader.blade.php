<!-- Loader Overlay -->
<div id="loader-overlay">
    <div class="loader-container">
        <div class="spinner-border text-light" role="status">
            <span class="visually-hidden">Loading...</span>
        </div>
        <p class="text-white mt-2">Processing...</p>
    </div>
</div>
