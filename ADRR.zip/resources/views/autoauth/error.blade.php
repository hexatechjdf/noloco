@extends('autoauth.public')
@section('title', 'Error')

@section('section')
<div class="row">
    <h1>Something Went Wrong</h1>
</div>
@endsection
@section('js')
@endsection
