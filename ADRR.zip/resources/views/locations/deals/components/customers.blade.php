<div class="py-2 ">
    <label>Customers</label>
    <select class="form-select  select2 form-control customer" name="customer">
        @include('locations.deals.components.customersList')
    </select>
</div>

{{-- <div class="py-2 ">
    <label>Coborrower</label>
    <select class="form-select custom_select select2 form-control" name="customer">
        @include('locations.deals.components.customersList')
    </select>
</div> --}}
