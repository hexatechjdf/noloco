<?php

return [

    'app' => [
        'name' => '',
        'key' => '',
    ],
];
